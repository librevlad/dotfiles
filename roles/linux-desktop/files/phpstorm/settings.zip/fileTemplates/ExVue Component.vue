<template>
    <div>
        
    </div>
</template>
<script>
    export default {

        props: [],

        data()
        {
            return {
               
            }
        },

        mounted()
        {
     
        },
        methods: {
        
        }
    }
</script>
<style lang="scss" scoped>

</style>
